<?php  if (count($errors) > 0) : ?>

<?php  endif ?>